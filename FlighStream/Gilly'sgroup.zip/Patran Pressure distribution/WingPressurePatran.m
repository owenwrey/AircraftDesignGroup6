clear
close all
clc

%% Load FlightStream pressure data
% Columns: X, Y, Z, Pressure (psi, absolute)
data = readmatrix('Pressure_output_for_NACA64206.csv');

X = data(:,1);  % Chordwise (inches)
Y = data(:,2);  % Spanwise (inches)
Z = data(:,3);  % Vertical (inches)
P_abs = data(:,4);  % Absolute pressure (psi)

% Convert to gauge pressure (subtract atmospheric)
P_atm = 14.6959;  % psi
P_gauge = P_abs - P_atm;

%% Split upper and lower surfaces by Z coordinate
% Upper surface: Z >= 0 (above chord plane)
% Lower surface: Z <  0 (below chord plane)
upperIdx = Z >= 0;
lowerIdx = Z <  0;

%% Build Patran-ready output: [X, Y, Pressure]
UpperPressureField = [X(upperIdx), Y(upperIdx), P_gauge(upperIdx)];
LowerPressureField = [X(lowerIdx), Y(lowerIdx), P_gauge(lowerIdx)];

%% Write CSVs
writematrix(UpperPressureField, 'UpperPressureField.csv', 'Delimiter', 'comma')
writematrix(LowerPressureField, 'LowerPressureField.csv', 'Delimiter', 'comma')

%% Plot to verify the split looks correct
figure
subplot(1,2,1)
scatter(X(upperIdx), Y(upperIdx), 15, P_gauge(upperIdx), 'filled')
colorbar; colormap jet
title('Upper Surface Gauge Pressure (psi)')
xlabel('X - Chordwise (in)'); ylabel('Y - Spanwise (in)')

subplot(1,2,2)
scatter(X(lowerIdx), Y(lowerIdx), 15, P_gauge(lowerIdx), 'filled')
colorbar; colormap jet
title('Lower Surface Gauge Pressure (psi)')
xlabel('X - Chordwise (in)'); ylabel('Y - Spanwise (in)')

%% Sanity check output
disp('=== Output Summary ===')
disp(['Total points:         ' num2str(length(P_gauge))])
disp(['Upper surface points: ' num2str(sum(upperIdx))])
disp(['Lower surface points: ' num2str(sum(lowerIdx))])
disp(['Upper pressure range: ' num2str(min(P_gauge(upperIdx)),'%.4f') ...
      ' to ' num2str(max(P_gauge(upperIdx)),'%.4f') ' psi'])
disp(['Lower pressure range: ' num2str(min(P_gauge(lowerIdx)),'%.4f') ...
      ' to ' num2str(max(P_gauge(lowerIdx)),'%.4f') ' psi'])
disp('Files written: UpperPressureField.csv, LowerPressureField.csv')
